Eika Pensjonscup – prototype v3

Oppgradert med:
- Mer polert Eika-inspirert visuelt uttrykk
- Progressbar mellom spørsmål
- Tydeligere timer
- Forbedrede knapper, kort og typografi
- 40 banker i banklisten
- Svart tekst på svaralternativene
- Samme quiz- og leaderboard-funksjonalitet som tidligere
