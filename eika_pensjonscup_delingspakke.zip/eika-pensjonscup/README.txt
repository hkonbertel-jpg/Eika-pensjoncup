# Eika Pensjonscup – delingspakke

Denne mappen er klar for enkel publisering som en statisk nettside.

## GitHub Pages
1. Opprett et nytt repository på GitHub, f.eks. `eika-pensjonscup`.
2. Last opp `index.html` fra denne mappen.
3. Gå til Settings → Pages.
4. Velg `Deploy from a branch`.
5. Velg branch `main` og mappe `/ (root)`.
6. GitHub gir deg en delingslenke etter publisering.

## Viktig om prototypen
Dette er foreløpig en frontend-prototype. Resultater/leaderboard lagres lokalt i nettleseren. Kollegaer deler derfor ikke samme leaderboard ennå.

Neste steg kan være å koble prototypen til en felles database slik at alle deltakere ser samme live-ranking.
